utilities/fsl_io.o utilities/fsl_io.d: ../utilities/fsl_io.c \
 ../utilities/fsl_io.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_common.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/fsl_device_registers.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/MKL46Z4.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/core_cm0plus.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_version.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_compiler.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_gcc.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/system_MKL46Z4.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/MKL46Z4_features.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_clock.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_common.h \
 ../utilities/fsl_debug_console_conf.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_uart.h \
 C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_lpsci.h
../utilities/fsl_io.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_common.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/fsl_device_registers.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/MKL46Z4.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/core_cm0plus.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_version.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_compiler.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/cmsis_gcc.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/system_MKL46Z4.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\CMSIS/MKL46Z4_features.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_clock.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_common.h:
../utilities/fsl_debug_console_conf.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_uart.h:
C:\Users\babbi\Documents\MCUXpressoIDE_11.6.1_8255\workspace\Sensors\drivers/fsl_lpsci.h:
